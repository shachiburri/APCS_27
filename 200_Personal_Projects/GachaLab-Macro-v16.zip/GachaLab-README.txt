GACHA LAB MACRO v16 - AutoHotkey v2

HIGH-GENERATION SHIPPING FIX
At generation 1743 in the saved game's configuration, the native payout cap
(30 * 1.5^generation) becomes Infinity in JavaScript. Earlier macro versions
rejected those stats even when the actual Transistor payout remained finite.
Earliest shipping now uses the valid native payout independently of that cap.
Minimum payout and optional balance spending still apply normally.
Percentage calculations multiply by the fraction first to prevent premature
overflow while the cap is still finite. If the cap itself exceeds number range,
percentage mode explains that limit and waits; select earliest mode to continue.
The macro does not alter the game's numbers or replace its payout calculation.
Invalid/non-finite actual payouts still block shipping and show a diagnostic.
Further numerical limits inside the game itself are not repaired by this helper.

SHIPPING UPDATE
"Spend remaining Food Bits before shipping" is now optional and OFF by default,
including when upgrading from v14. With it off, the macro ships immediately when
the selected earliest/percentage/minimum-payout target is reached. If spending
is still needed, it buys only until the target is reached, checking after each
confirmed level. It does not finish the rest of the upgrade queue before shipping.
Enable this checkbox only if you want to spend the remaining balance first.
The live shipping target display also refreshes during the purchase sequence.

SPEED UPDATE
Removed the fixed 600 ms management cooldown. Each confirmed purchase immediately
unlocks the next one. Shipping stages also continue without that cooldown.
New Lab buying mode defaults to "all affordable - fast bulk buying". It buys all
unlocked, affordable levels, including offline upgrades, taking the largest
affordable purchase first. Select "best active value" to restore the old ranking.
Ready shipments take priority over the Breakthrough buying queue. Permanent
upgrades are considered again after the reset or while waiting to become eligible.
The game has no bulk-purchase button in the saved version, so each level still
needs a confirmed game response. Server response time can limit purchase speed.
Existing feature settings and learned typing times are preserved.

INSTALL / UPDATE
1. Refresh the game once to remove the old browser helper.
2. Keep GachaLab.ahk and GachaLab.js together and run GachaLab.ahk with AutoHotkey v2.
3. Open The Lab in Chrome or Edge and press F8.
4. Configure the checkboxes and shipping controls in the draggable panel.

F8 = Start / pause. F9 = Stop with the game tab selected.
The panel has Start/Pause and Close buttons. Drag its title to move it.
It scrolls on smaller screens. Settings survive refreshes; panel position resets.
Closing AutoHotkey alone does not stop a helper already running in the page.
Use F9, Pause, Close, or refresh to stop future actions. A game request already
sent to the server can still finish after you pause.

DEFAULTS
Auto-click, Auto-type, Auto-repair, Buy Lab upgrades and Buy Breakthroughs are on.
Auto-shipping is OFF initially. Enable it after choosing a shipping mode.
Full balance spending before shipping is OFF initially; the target takes priority.
Once you change settings, those choices are remembered, including auto-shipping.
Starting with F8 uses the remembered choices. A page refresh requires F8 again.

INDEPENDENT CONTROLS
Auto-click Tap!: clicks the game's Tap! control, using pointer press/release events.
Auto-type Code Sprint: reads and types the current displayed Sprint code.
Auto-repair pets: opens Squash me!/Click to squash!, types the repair code if
needed, and resumes farming. It works even when Sprint typing is turned off.
Buy Lab upgrades: "all affordable" buys every unlocked affordable level as fast
as confirmed responses permit. "Best active value" compares estimated additional
active income per cost. The new buying mode initially defaults to all affordable.
Buy useful Breakthroughs: spends Transistors on useful permanent upgrades.
Keep N Transistors unspent: reserves that balance during automatic Breakthrough buying.
Include faster-rebuild upgrades: enables rebuild/prestige benefits in Breakthrough
ranking when auto-shipping is also enabled.

AUTO-SHIPPING
As soon as eligible: ships once the game's minimum spending requirement is met.
Percentage of cap: waits until the payout reaches at least the chosen percentage
of that generation's displayed Transistor cap, rounding the required payout up.
Minimum payout: optional additional requirement applied to either mode. Zero
adds no extra requirement. A minimum greater than the cap cannot be reached.
High percentages can take much longer because of diminishing returns.
When the game's cap exceeds the browser's number range, earliest mode continues
using a valid payout; percentage mode shows an explanation and does not ship.

BEFORE AN AUTOMATIC SHIPMENT
With "Spend remaining Food Bits before shipping" OFF, a ready payout ships
immediately. If the target is not reached but spending can reach it, the macro
buys regular upgrades and rechecks after every response. It stops spending as
soon as the chosen target is reached, even when many upgrades remain affordable.
The normal Lab buying mode never overrides an eligible automatic shipment.

With that checkbox ON, the macro spends currently available Food Bits on
unlocked, affordable regular Lab upgrades, including Night Shift/Nap Pods and
other upgrades normally skipped for active farming. This happens even if normal
automatic Lab buying is off.
It refreshes the balance, rechecks the target, and opens/confirms the shipping
popup only for its own current-generation shipping sequence. It does not wait
to earn funds for future purchases during this spend-down. Discrete upgrade
prices can leave an unspendable remainder, and income can accrue during requests;
it cannot guarantee an exact zero balance or a globally optimal packing of purchases.
If spend-down does not reach the chosen payout, it resumes farming instead.
Breakthrough buying does not delay a ready shipment. It continues afterward with
the new Transistors and the game's confirmed new-generation state.

Shipping resets Food Bits, regular Lab upgrades and the run's leaderboard score.
Plushies, cards, Bytes, mentors, Transistors and Breakthroughs are retained by the game.
After a confirmed generation increase, the macro continues with the new generation
and invests earned Transistors if Breakthrough buying is enabled.
Auto-shipping off cancels shipping confirmations and continues normal farming.
Turning it off or pausing before confirmation prevents a new reset request.
Turning it off after confirmation was sent cannot undo the game's pending request.

PURCHASE PRIORITIES
All affordable: immediately buys the largest affordable regular upgrade and
continues after each confirmation, including Night Shift and Nap Pods.
Best active value: estimates active income gained per Food Bit spent. Night Shift,
Nap Pods and zero-income bonuses are skipped. It can save up to 30 seconds for
a better-value target while another useful purchase is affordable; otherwise it
buys the best affordable value. Purchases wait if game data is unavailable.

Breakthroughs: compares direct active-income gains after subtracting the purchase
cost from the Transistor balance. This also accounts for lost Transistor Interest
when spending a reserve. Empty pet/mentor slots, cosmetic upgrades, offline-only
bonuses and extra Sprint time are not purchased when they add no modeled income.
Robotic Arm is evaluated as additional income, including when auto-clicking is off.
Network-on-Chip and 5G only gain priority when their conditions produce income.
The macro can save Transistors when an affordable weak purchase is substantially
worse than the best-value future target. It does not blindly spend the last coins.

With auto-shipping and faster-rebuild upgrades enabled, ranking uses 65% current
income benefit and 35% rebuilt-Lab income benefit. Cache Memory uses the regular
upgrade levels it could actually retain. Fab Plant also gets a planning allowance
for reduced generation spending requirements. These are practical heuristics,
not a guarantee of the mathematically optimal long-term route.
This version does not automatically equip extra pets or mentors into new slots.

The active model assumes x10 Sprint when auto-typing is on and 15 credited manual
taps per second when auto-clicking is on, limited by the game's configured cap.
With those toggles off it uses no manual taps and no maintained Sprint bonus.
Robotic Arm income is added independently. These are planning estimates, not a
measurement of the live server's credited click rate.

TIMING
The panel's Timing section changes minimum Sprint/repair line durations and tap
interval (0 = fastest browser timer rate). Long lines and learned speed-warning
limits may require longer than the selected minimum. Defaults are 1000 ms Sprint,
1500 ms repairs, and no intentional break between accepted lines.
Characters are spread out; rendering stalls extend the line instead of creating
catch-up bursts. The last character is held until its timing requirement is met,
because the game auto-submits a matching line on input. Repair popups get 120 ms
for focus to settle. A speed warning triggers cooldown and learned slower timing;
after two unsuccessful slower retries the macro pauses. Learning survives refreshes.

PACING / CONFIRMATION
Purchases, balance refreshes and shipping are serialized. A new purchase waits
only for the previous level change, without a fixed cooldown; shipping waits for
a confirmed generation change. When no action is available, checks run every
100 ms. Shipping transitions run on the next browser timer tick.
Final code submission and taps briefly wait during pending transactions to avoid
racing those game requests. A request not confirmed after 15 seconds pauses the
macro rather than repeatedly confirming a potentially irreversible reset.
Counters for Lab purchases, Breakthroughs and shipments use confirmed game state
changes. Tap, code and repair counters count input attempts.

The helper reads published Lab/inventory data and computes hypothetical upgrades
on copies. Actual purchases and shipping use ordinary game buttons. For fresh
shipping balances it calls the game's existing balance-sync routine. It does not
forge currency, change inventory directly, or bypass server validation.
Keep the game tab visible and the browser unminimized. Other open game popups
block background farming so the macro does not click through them.

VALIDATION
Verified against a local browser simulation using the saved game's actual rate
and payout functions. Checks cover independent feature toggles, popup repairs,
active upgrade filtering, Breakthrough budgets/reserves, percentage and earliest
shipping, minimum payouts, full affordable spend-down, repeated generations,
pausing/disabling shipping, action serialization, and settings retained on reload.
Speed checks cover buying 110 affordable levels in bulk, optionally draining a
rich run before shipping, skipping the Breakthrough queue for a ready shipment,
and shipping a ready rich run with zero additional purchases. Earliest, percentage
and minimum-payout tests also verify stopping immediately after the purchase
that reaches the target. Response waiting is retained in all tests.
High-generation regression checks cross generations 1742, 1743 and 1744, buy
only enough to meet the target at an overflowed cap, enforce minimum payouts,
reject zero/invalid payouts, and explain unrepresentable percentage targets.
The expanded panel was visually checked and its drag behavior tested.
Not tested on the live website; future game updates can change selectors or rules.
